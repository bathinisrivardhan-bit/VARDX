python AutismDetection.py
pause